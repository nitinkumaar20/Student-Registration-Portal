import React from 'react'

export default function Result() {
  return (
    <div ><h1>Nothing to Show!</h1></div>
  )
}
